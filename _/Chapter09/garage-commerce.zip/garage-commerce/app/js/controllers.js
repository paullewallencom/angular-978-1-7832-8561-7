'use strict';
angular.module('myApp.controllers', []).controller('ProductsCtrl', ['$scope', '$stateParams', 'AWSservice',
    function($scope, $stateParams, AWSservice) {
        $scope.category = $stateParams.category;

        AWSservice.getProductsByCategory($scope.category).then(
            function(data) {
                $scope.productsListing = data.Items;
            });
    }
])

.controller('ProductDetailsCtrl', ['$scope', '$stateParams','AWSservice', '$log',
    function($scope, $stateParams, AWSservice, $log) {
        var id = $stateParams.id;
        
        AWSservice.getProductDetails(id).then(
            function(data) {
                $scope.product = data.Item;

            }, function(err) {
                $log.error(err);
            });
        $scope.addToCart = function(product_id) {

            $scope.shoppingBasket.push(product_id);
            $log.log(JSON.stringify($scope.shoppingBasket));
        };
    }
])
    .controller('AppCtrl', ['$scope', 'categoryService', 'Facebook', 'authService', 'AWSservice', '$log',
        function($scope, categoryService, Facebook, authService, AWSservice, $log) {
            $scope.categories = categoryService.getCategories();
            $scope.user = {};
            $scope.shoppingBasket = [];
            $scope.s3Bucket=AWSservice.getBucketName();
            Facebook.getLoginStatus(function(response) {
                if (response.status === 'connected') {
                    authService.getUserInfo().then(function(data) {
                        $scope.user = data;
                    });
                    //Initialize AWS
                    var token = response.authResponse.accessToken;
                    
/*---- Commented after refactoring this as Resolves into the StateProvider -- */
                    // AWSservice.initializeAWS(token).then(
                    //     function(data) {
                    //         $log.info(data)
                    //     })
                } else {
                    Facebook.login();
                }
            });
        }
    ])
    .controller('AddProductsCtrl', ['$scope', 'categoryService', 'authService', 'AWSservice',
        function($scope, categoryService, authService, AWSservice) {
            $scope.categories = categoryService.getCategories();
            $scope.newProduct = {};

            $scope.addProduct = function() {
                $scope.newProduct.userId = $scope.user.id;
                $scope.newProduct.userName = $scope.user.name;
                //$scope.newProduct.picUrl = 'sw3/someURL';
                AWSservice.saveProductData($scope.newProduct);

            };
            $scope.uploadImage = function(files) {
               

                AWSservice.uploadPic(files).then(
                    function(data) {
                        $scope.newProduct.picUrl = data;
                        $scope.uploadedPicURL = "https://s3.amazonaws.com/" + $scope.s3Bucket + "/" + data;
                    }, function(err) {
                        $log.error(err);
                    });
            };
        }
    ])
    .controller('CheckoutCtrl', ['$scope', 'AWSservice',
        function($scope, AWSservice) {
            $scope.totalPrice = 0;
            $scope.checkoutList = [];
            angular.forEach($scope.shoppingBasket, function(item) {
                AWSservice.getProductDetails(item).then(
                    function(data) {

                        var basketItem = {};
                        basketItem.title = data.Item.title.S;
                        basketItem.price = data.Item.price.N;
                        $scope.totalPrice = $scope.totalPrice +
                            parseInt(basketItem.price);
                        $scope.checkoutList.push(basketItem);
                    }, function(err) {
                        $log.error(err);
                    }
                );
            });
            $scope.placeOrder=function(){
AWSservice.saveOrder($scope.checkoutList,$scope.user.id);
};
        }
    ]);

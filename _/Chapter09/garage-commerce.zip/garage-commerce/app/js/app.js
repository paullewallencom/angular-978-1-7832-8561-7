'use strict';


// Declare app level module which depends on filters, and services
angular.module('myApp', [
    'ui.router',
    'myApp.filters',
    'myApp.services',
    'myApp.directives',
    'myApp.controllers',
    'ngAnimate',
    'facebook'
]).

config(['$stateProvider',
    function($stateProvider) {
        $stateProvider.state('add', {
            url: '/add',
            templateUrl: 'partials/add-products.html',
            controller: 'AddProductsCtrl',



        });

        $stateProvider.state('checkout', {
            url: '/checkout',
            templateUrl: 'partials/checkout.html',
            controller: 'CheckoutCtrl',
        });

        $stateProvider.state('category', {
            url: '/:category',
            templateUrl: 'partials/products.html',
            controller: 'ProductsCtrl',
            resolve: {
                Facebook: 'Facebook',
                FBtoken: function(Facebook) {
                    return Facebook.getLoginStatus(function(response) {
                        if (response.status == 'connected') {
                            return response.token;
                        }

                    });
                },
                AWSinit: function(FBtoken, AWSservice) {
                    var token = FBtoken.authResponse.accessToken;
                    return AWSservice.initializeAWS(token).$promise;
                }

            },
        });

        $stateProvider.state('category.products', {
            url: '/:id',
            templateUrl: 'partials/products.details.html',
            controller: 'ProductDetailsCtrl'
        });
    }
])
    .config(['FacebookProvider',
        function(FacebookProvider) {
            FacebookProvider.init('facebook App Id');

        }
    ])

.config(['AWSserviceProvider',
    function(AWSserviceProvider) {

        AWSserviceProvider.setRoleArn('arn name');
        AWSserviceProvider.setRegion('AWS region name');
        AWSserviceProvider.setS3Bucket('S3 bucket name');
        AWSserviceProvider.setDynamoTableName('dynamo table name');
    }
]);

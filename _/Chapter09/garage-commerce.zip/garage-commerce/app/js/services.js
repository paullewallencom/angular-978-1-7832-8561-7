'use strict';

/* Services */


// Demonstrate how to register services
// In this case it is a simple value service.
angular.module('myApp.services', []).
value('version', '0.1')
    .factory("categoryService", [

        function() {
            return {
                getCategories: function() {
                    var categories = ['Toys', 'Electronics', 'Books',
                        'Furniture', 'Collectibles'
                    ];
                    return categories;
                }
            };
        }
    ])
    .factory('authService', ['$q', 'Facebook',
        function($q, Facebook) {
            return {
                getUserInfo: function() {
                    var d = $q.defer();
                    Facebook.api('/me', function(response) {
                        d.resolve(response);
                    });
                    return d.promise;

                },
            };
        }
    ])
    .provider('AWSservice', [

        function() {
            var region, S3bucketName, dynamoTableName, roleArn, dynamo, s3bucket;
            this.setRoleArn = function(arn) {
                roleArn = arn;

            };
            this.setRegion = function(myRegion) {
                region = myRegion;
            };
            this.setS3Bucket = function(s3) {
                S3bucketName = s3;
            };
            this.setDynamoTableName = function(dynamo) {
                dynamoTableName = dynamo;
            };
            this.$get = function($q, $log) {
                return {
                    getBucketName: function() {
                        return S3bucketName;
                    },
                    initializeAWS: function(token) {
                        var d = $q.defer();
                        var AWSCredentials = {
                            RoleArn: roleArn,

                            ProviderId: 'graph.facebook.com',
                            WebIdentityToken: token
                        };
                        AWS.config.credentials = new AWS.WebIdentityCredentials(AWSCredentials);
                        d.resolve(AWS.config.credentials);
                        AWS.config.region = region;
                        dynamo = new AWS.DynamoDB({
                            params: {
                                TableName: dynamoTableName
                            }
                        });
                        s3bucket = new AWS.S3({
                            params: {
                                Bucket: S3bucketName
                            }
                        });
                        return d.promise;
                    },
                    saveProductData: function(newProduct) {
                        var timestamp = new Date().getTime();
                        var UUID = newProduct.userId + "-" + timestamp;
                        var productData = {
                            Item: {
                                'product_id': {
                                    S: UUID
                                },
                                'category': {
                                    S: newProduct.category
                                },
                                'title': {
                                    S: newProduct.title
                                },
                                'description': {
                                    S: newProduct.description
                                },
                                'price': {
                                    N: newProduct.price.toString()
                                },
                                'productPicUrl': {
                                    S: newProduct.picUrl
                                },

                                'userId': {
                                    S: newProduct.userId
                                },
                                'userName': {
                                    S: newProduct.userName
                                }
                            }
                        };
                        dynamo.putItem(productData, function(err) {
                            if (err) {
                                $log.error(err);
                            } else {
                                $log.info('Product Saved!!');
                            }
                        });
                    },
                    getProductsByCategory: function(category) {
                        var d = $q.defer();
                        var params = {
                            'Limit': 100,
                            'ScanFilter': {
                                category: {
                                    AttributeValueList: [{
                                        S: category
                                    }],
                                    ComparisonOperator: 'EQ'
                                }
                            }
                        };
                        dynamo.scan(params, function(err, data) {
                            if (data) {
                                d.resolve(data);
                            } else if (err) {
                                $log.error(err);
                            }
                        });
                        return d.promise;
                    },

                    uploadPic: function(files) {
                        var d = $q.defer();
                        var file = files[0];
                        var data = {
                            Key: file.name,
                            Body: file,
                            ContentType: file.type
                        };
                        s3bucket.putObject(data, function(err, data) {
                            var fileName = file.name;
                            d.resolve(fileName);
                            if (err) {
                                d.reject(err);
                                $log.error(err);
                            } else {
                                $log.info('successfully uploaded');
                            }
                        });
                        return d.promise;
                    },

                    getProductDetails: function(id) {
                        var d = $q.defer();

                        var params = {
                            'Key': {
                                'product_id': {
                                    'S': id
                                }
                            }
                        };
                        dynamo.getItem(params, function(err, data) {
                            if (err) $log.error('err= ' + err);
                            if (data) {
                                d.resolve(data);
                            }
                        });
                        return d.promise;
                    },



                    saveOrder: function(orders, buyer_id) {
                        var orderString = JSON.stringify(orders);
                        AWS.config.region = region;
                        var timestamp = new Date().getTime();
                        var UUID = "#" + buyer_id + "-" + timestamp;
                        var dynamo = new AWS.DynamoDB({

                            params: {
                                TableName: 'garage-commerce-orders'
                            }
                        });
                        var orderData = {
                            Item: {
                                'order_id': {
                                    S: UUID
                                },
                                'buyer_id': {
                                    S: buyer_id
                                },
                                'order_data': {
                                    S: orderString
                                }
                            }
                        };
                        dynamo.putItem(orderData, function(err, data) {
                            if (err) $log.error(err);
                        });
                    }
                };


            };

        }
    ]);
